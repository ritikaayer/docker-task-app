const API = "/api/tasks"; // nginx forwards /api to the backend container

const listEl = document.getElementById("list");
const emptyEl = document.getElementById("empty");
const summaryEl = document.getElementById("summary");
const errorEl = document.getElementById("error");
const form = document.getElementById("add-form");
const input = document.getElementById("title");

let tasks = [];
let filter = "all";

function showError(msg) {
  errorEl.textContent = msg || "";
  errorEl.hidden = !msg;
}

async function request(url, options) {
  try {
    const res = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error || `Request failed (${res.status})`);
    }
    showError("");
    return res.status === 204 ? null : res.json();
  } catch (err) {
    showError(err.message || "Could not reach the server. Check that it is running.");
    throw err;
  }
}

function render() {
  const visible = tasks.filter((t) =>
    filter === "all" ? true : filter === "done" ? t.done : !t.done
  );
  listEl.innerHTML = "";
  visible.forEach((t) => {
    const li = document.createElement("li");
    if (t.done) li.classList.add("done");

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = t.done;
    cb.setAttribute("aria-label", `Mark "${t.title}" as ${t.done ? "open" : "done"}`);
    cb.addEventListener("change", () => toggle(t));

    const span = document.createElement("span");
    span.className = "text";
    span.textContent = t.title; // textContent avoids XSS

    const del = document.createElement("button");
    del.className = "del";
    del.textContent = "Delete";
    del.setAttribute("aria-label", `Delete "${t.title}"`);
    del.addEventListener("click", () => remove(t));

    li.append(cb, span, del);
    listEl.appendChild(li);
  });

  emptyEl.hidden = visible.length > 0;
  const open = tasks.filter((t) => !t.done).length;
  summaryEl.textContent = tasks.length
    ? `${open} open, ${tasks.length - open} done`
    : "No tasks yet.";
}

async function loadTasks() {
  tasks = await request(API);
  render();
}
async function toggle(task) {
  const updated = await request(`${API}/${task.id}`, {
    method: "PATCH",
    body: JSON.stringify({ done: !task.done }),
  });
  Object.assign(task, updated);
  render();
}
async function remove(task) {
  await request(`${API}/${task.id}`, { method: "DELETE" });
  tasks = tasks.filter((t) => t.id !== task.id);
  render();
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = input.value.trim();
  if (!title) return;
  const created = await request(API, { method: "POST", body: JSON.stringify({ title }) });
  tasks.unshift(created);
  input.value = "";
  render();
});

document.querySelectorAll(".filters button").forEach((btn) =>
  btn.addEventListener("click", () => {
    filter = btn.dataset.filter;
    document.querySelectorAll(".filters button").forEach((b) => b.classList.toggle("active", b === btn));
    render();
  })
);

loadTasks().catch(() => { summaryEl.textContent = "Tasks unavailable."; });
