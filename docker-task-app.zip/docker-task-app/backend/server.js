const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 5000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "tasks.json");

app.use(cors());
app.use(express.json());

// ---- tiny JSON-file "database" (persisted through a Docker volume) ----
fs.mkdirSync(DATA_DIR, { recursive: true });

function load() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return [];
  }
}
function save(tasks) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2));
}

// ---- routes ----
app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.get("/api/tasks", (_req, res) => res.json(load()));

app.post("/api/tasks", (req, res) => {
  const title = (req.body.title || "").trim();
  if (!title) return res.status(400).json({ error: "Title is required." });
  const task = {
    id: crypto.randomUUID(),
    title: title.slice(0, 200),
    done: false,
    createdAt: new Date().toISOString(),
  };
  const tasks = load();
  tasks.unshift(task);
  save(tasks);
  res.status(201).json(task);
});

app.patch("/api/tasks/:id", (req, res) => {
  const tasks = load();
  const task = tasks.find((t) => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found." });
  if (typeof req.body.done === "boolean") task.done = req.body.done;
  if (typeof req.body.title === "string" && req.body.title.trim())
    task.title = req.body.title.trim().slice(0, 200);
  save(tasks);
  res.json(task);
});

app.delete("/api/tasks/:id", (req, res) => {
  const tasks = load();
  const next = tasks.filter((t) => t.id !== req.params.id);
  if (next.length === tasks.length)
    return res.status(404).json({ error: "Task not found." });
  save(next);
  res.status(204).end();
});

app.listen(PORT, "0.0.0.0", () =>
  console.log(`Backend listening on port ${PORT}`)
);
