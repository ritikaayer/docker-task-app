# Taskyard – Dockerized Task Manager

A small full-stack web app running in Docker containers.

- **Frontend:** HTML, CSS and vanilla JavaScript served by Nginx
- **Backend:** Node.js + Express REST API
- **Storage:** JSON file kept in a Docker volume (survives restarts)
- **Orchestration:** Docker Compose (2 containers on one network)

## Architecture

```
Browser ──► frontend (nginx :80, published on host :8080)
                │  /api/*  (reverse proxy)
                ▼
            backend (Express :5000) ──► volume "task-data" (/data/tasks.json)
```

## Project structure

```
.
├── docker-compose.yml
├── backend/
│   ├── Dockerfile
│   ├── package.json
│   └── server.js
└── frontend/
    ├── Dockerfile
    ├── nginx.conf
    ├── index.html
    ├── style.css
    └── app.js
```

## Run it

Requirements: Docker and Docker Compose.

```bash
git clone <your-repo-url>
cd <your-repo-folder>
docker compose up --build
```

Open **http://localhost:8080**

Stop with `Ctrl+C`, or run `docker compose down`.
Add `-v` to also delete the saved tasks: `docker compose down -v`.

## API

| Method | Endpoint          | Description                       |
|--------|-------------------|-----------------------------------|
| GET    | `/api/health`     | Health check                      |
| GET    | `/api/tasks`      | List all tasks                    |
| POST   | `/api/tasks`      | Create a task `{ "title": "…" }`  |
| PATCH  | `/api/tasks/:id`  | Update `{ "done": true }` / title |
| DELETE | `/api/tasks/:id`  | Delete a task                     |

## Useful commands

```bash
docker compose ps            # see running containers
docker compose logs -f       # follow logs
docker compose up -d --build # run in the background
```
